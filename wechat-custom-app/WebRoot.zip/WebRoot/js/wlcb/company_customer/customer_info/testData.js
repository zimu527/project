/**
 * Created by Administrator on 2017/5/22.
 */
  //客户信息查询>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  var cmslistTest = [
  {
    name: 'Male',
    imageurl: '../../img/wlcb/icon/wl170509001.jpg',
    phone: '1552266666'
  },
  {
    name: 'Male',
    imageurl: '../../img/wlcb/icon/wl170509001.jpg',
    phone: '1552266666'
  }
];

var csmlistTestData =[
    {
      name: 'Male',
      imageurl: '../../img/wlcb/icon/wl170509001.jpg',
      phone: '1552266666',
//            openid: 'ogoIswODSbR0lXYuNM5FnSgQikwI',
//            accountid: 'oid8a2b294855f2d9010155f2ee7057004d'
      'companylist':[
        {
          'id':1,
          'name':'乌兰察布教育局',
          'userlist':[
            {
              'id':1,
              'phone':'18000000000',
              'name':'张丹',
              'type':1//成员类型 0-未知 1-负责人 2-联系人 3-普通成员
            },
            {
              'id':2,
              'phone':'18000000000',
              'name':'张丹',
              'type':2//成员类型 0-未知 1-负责人 2-联系人 3-普通成员
            },
            {
              'id':3,
              'phone':'18000000000',
              'name':'张丹',
              'type':3//成员类型 0-未知 1-负责人 2-联系人 3-普通成员
            }
          ]
        },
        {
          'id':1,
          'name':'乌兰察布税务局',
          'userlist':[
            {
              'id':1,
              'phone':'18000000000',
              'name':'张丹',
              'type':1//成员类型 0-未知 1-负责人 2-联系人 3-普通成员
            },
            {
              'id':1,
              'phone':'18000000000',
              'name':'张丹',
              'type':1//成员类型 0-未知 1-负责人 2-联系人 3-普通成员
            },
            {
              'id':1,
              'phone':'18000000000',
              'name':'张丹',
              'type':1//成员类型 0-未知 1-负责人 2-联系人 3-普通成员
            }
          ]
        }
      ]

    },
    {
      name: 'Male',
      imageurl: '../../img/wlcb/icon/wl170509001.jpg',
      phone: '1552266666'
//                openid: 'ogoIswODSbR0lXYuNM5FnSgQikwI',
//                accountid: 'oid8a2b294855f2d9010155f2ee7057004d'
    }
  ]
  ;
